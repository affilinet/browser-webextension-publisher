(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _storage = require('../utils/storage');

var _storage2 = _interopRequireDefault(_storage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var publisherId = null;
var webservicePassword = null;

_storage2.default.get('publisherId', function (results) {
    publisherId = results['publisherId'] || null;
});
_storage2.default.get('webservicePassword', function (results) {
    webservicePassword = results['webservicePassword'] || null;
});

var myProgramsCache = [];

var token = false;
var validUntil = false;

function getXml(string) {
    var parser = new DOMParser();
    var document = parser.parseFromString(string, "application/xml");
    if (_hasParseError(document)) {
        console.error('XML PARSER ERROR: Could not parse Response from Webservice', document);
        console.error(string);
    }
    return document;
}

/**
 * https://stackoverflow.com/questions/11563554/how-do-i-detect-xml-parsing-errors-when-using-javascripts-domparser-in-a-cross
 * Note this might not work on IE
 * @param parsedDocument
 * @returns {boolean}
 * @private
 */
function _hasParseError(parsedDocument) {
    // parser and parsererrorNS could be cached on startup for efficiency
    var parser = new DOMParser(),
        errorneousParse = parser.parseFromString('<', 'text/xml'),
        parsererrorNS = errorneousParse.getElementsByTagName("parsererror")[0].namespaceURI;

    if (parsererrorNS === 'http://www.w3.org/1999/xhtml') {
        // In PhantomJS the parseerror element doesn't seem to have a special namespace, so we are just guessing here :(
        return parsedDocument.getElementsByTagName("parsererror").length > 0;
    }
    return parsedDocument.getElementsByTagNameNS(parsererrorNS, 'parsererror').length > 0;
}

function _sendRequest(requestBody, url, soap_action) {
    return new Promise(function (resolve, reject) {
        console.log('new xhr', url, soap_action);
        var xhr = new XMLHttpRequest();

        xhr.onloadend = function (event) {
            if (xhr.status === 200) {
                resolve(xhr.responseText);
            } else {
                console.debug('ERROR response with status ' + xhr.status);
                console.debug(xhr.response);
                reject(xhr);
            }
        };
        xhr.open('post', url); // event listeners musst be attached before!
        xhr.setRequestHeader("SOAPAction", soap_action);
        xhr.setRequestHeader('Content-Type', 'text/xml; charset=utf-8');
        xhr.send(requestBody);
    });
}

var _tokenMustBeRefreshed = function _tokenMustBeRefreshed() {
    // Refresh token 2 minutes before it is invalid
    var now = Math.floor(Date.now()) + 2 * 60 * 1000;
    console.log('token is  valid  for another ', (validUntil - now) / 1000, ' seconds');
    if (token === false) {
        console.log('token is not set');
        return true;
    }
    return validUntil === false || validUntil < now;
};

var getToken = function getToken() {
    return new Promise(function (resolve, reject) {
        "use strict";

        if (_tokenMustBeRefreshed()) {
            console.log('token will get refreshed');
            Logon().then(function success(response) {
                var xmlDoc = getXml(response);
                var localToken = xmlDoc.getElementsByTagName('CredentialToken')[0].firstChild.nodeValue;
                token = localToken;
                _getTokenExpiration(token).then(function (tokenExpResult) {
                    var xmlDoc = getXml(tokenExpResult);
                    var expirationDate = xmlDoc.getElementsByTagName('ExpirationDate')[0].firstChild.nodeValue;
                    validUntil = new Date(expirationDate).getTime();
                    resolve(localToken);
                }, function (error) {
                    console.log('error in get token expiration ', error);
                    validUntil = 0;
                    reject(error);
                });
            }, function error(response) {
                console.log('error getting token');
                reject(response);
            });
        } else {
            resolve(token);
        }
    });
};

var _removeToken = function _removeToken() {
    token = false;
    validUntil = false;
};

var generateBodyForMyPrograms = function generateBodyForMyPrograms(token, page) {
    "use strict";

    return '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc" xmlns:pub="http://affilinet.framework.webservices/types/PublisherProgram" xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:GetProgramsRequest>' + '<svc:CredentialToken>' + token + '</svc:CredentialToken>' + '<svc:DisplaySettings><pub:CurrentPage>' + page + '</pub:CurrentPage><pub:PageSize>100</pub:PageSize></svc:DisplaySettings>' + '<svc:GetProgramsQuery>' +
    //'<pub:ProgramIds><arr:int>'+programId +'</arr:int></pub:ProgramIds>'+
    '<pub:PartnershipStatus>' + '<pub:ProgramPartnershipStatusEnum>Active</pub:ProgramPartnershipStatusEnum>' +
    //'<pub:ProgramPartnershipStatusEnum>Paused</pub:ProgramPartnershipStatusEnum>' +
    //'<pub:ProgramPartnershipStatusEnum>Waiting</pub:ProgramPartnershipStatusEnum>' +
    //'<pub:ProgramPartnershipStatusEnum>Cancelled</pub:ProgramPartnershipStatusEnum>' +
    '</pub:PartnershipStatus>' + '</svc:GetProgramsQuery>' + '</svc:GetProgramsRequest>' + '</soapenv:Body>' + '</soapenv:Envelope>';
};

var Logon = function Logon() {
    console.log('in logon');
    return new Promise(function (resolve, reject) {
        var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc" xmlns:typ="http://affilinet.framework.webservices/types">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:LogonRequestMsg>' + '<typ:Username>' + publisherId.trim() + '</typ:Username>' + '<typ:Password>' + webservicePassword.trim() + '</typ:Password>' + '<typ:WebServiceType>Publisher</typ:WebServiceType>' + '</svc:LogonRequestMsg>' + '</soapenv:Body>' + '</soapenv:Envelope>';
        _sendRequest(requestBody, 'https://api.affili.net/V2.0/Logon.svc', 'http://affilinet.framework.webservices/Svc/ServiceContract1/Logon').then(resolve, reject);
    });
};

var _getTokenExpiration = function _getTokenExpiration(token) {
    console.log('in GetTokenExpiration');
    return new Promise(function (resolve, reject) {
        var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc">' + '   <soapenv:Header/>' + '   <soapenv:Body>' + '      <svc:CredentialToken>' + token + '</svc:CredentialToken>' + '   </soapenv:Body>' + '</soapenv:Envelope>';
        _sendRequest(requestBody, 'https://api.affili.net/V2.0/Logon.svc', 'http://affilinet.framework.webservices/Svc/AuthenticationContract/GetIdentifierExpiration').then(resolve, reject);
    });
};
var _fetchAllMyProgramsPages = function _fetchAllMyProgramsPages(totalPages, token) {
    var startWith = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;

    _fetchOneOfMyProgramsPage(startWith, token).then(function (response) {
        var xmlDoc = getXml(response);
        var ProgramCollection = xmlDoc.getElementsByTagName("ProgramCollection")[0];
        var items = ProgramCollection.getElementsByTagName("a:Program");
        for (var i = 0; i < items.length; i++) {
            var newProgram = {
                programId: items[i].getElementsByTagName("a:ProgramId")[0].firstChild.nodeValue,
                programTitle: items[i].getElementsByTagName("a:ProgramTitle")[0].firstChild.nodeValue
            };
            myProgramsCache.push(newProgram);
        }

        if (startWith < totalPages) {
            _fetchAllMyProgramsPages(totalPages, token, startWith + 1);
        } else {
            console.log('INFO: Webservice returned', myProgramsCache.length, ' Program Partnership');
            _storage2.default.set({ myPrograms: myProgramsCache });
            console.debug('added page ' + myProgramsCache.length + ' Programs of myPrograms');
        }
    });
};

var _fetchOneOfMyProgramsPage = function _fetchOneOfMyProgramsPage(page, token) {
    console.log('Send Request for page', page);
    return _sendRequest(generateBodyForMyPrograms(token, page), 'https://api.affili.net/V2.0/PublisherProgram.svc', 'http://affilinet.framework.webservices/Svc/PublisherProgramContract/SearchPrograms');
};

var PublisherWebservice = function () {
    function PublisherWebservice() {
        _classCallCheck(this, PublisherWebservice);

        console.log('created Publisher Webservice');
    }

    _createClass(PublisherWebservice, [{
        key: 'GetLinkedAccounts',
        value: function GetLinkedAccounts() {
            console.debug('in Method GetLinkedAccounts');
            return new Promise(function (resolve, reject) {
                "use strict";

                getToken().then(function success(response) {
                    console.debug('in Method GetLinkedAccounts:success');

                    var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:GetLinkedAccountsRequest>' + '<svc:CredentialToken>' + response + '</svc:CredentialToken>' + '<svc:PublisherId>' + publisherId + '</svc:PublisherId>' + '</svc:GetLinkedAccountsRequest>' + '</soapenv:Body>' + '</soapenv:Envelope>';

                    console.debug('LinkedAccounts Request:');

                    _sendRequest(requestBody, 'http://api.affili.net/V2.0/AccountService.svc', 'http://affilinet.framework.webservices/Svc/AccountServiceContract/GetLinkedAccounts').then(resolve, reject);
                }, function error() {
                    console.debug('in Method GetLinkedAccounts:error');
                    reject();
                });
            });
        }
    }, {
        key: 'GetPublisherSummary',
        value: function GetPublisherSummary() {
            console.debug('in Method GetPublisherSummary');
            return new Promise(function (resolve, reject) {
                "use strict";

                getToken().then(function success(response) {
                    var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:CredentialToken>' + response + '</svc:CredentialToken>' + '</soapenv:Body>' + '</soapenv:Envelope>';
                    _sendRequest(requestBody, 'http://api.affili.net/V2.0/AccountService.svc', 'http://affilinet.framework.webservices/Svc/AccountServiceContract/GetPublisherSummary').then(resolve, reject);
                }, function error(error) {
                    console.debug('Error in Method GetPublisherSummary', error);
                    reject(error);
                });
            });
        }
    }, {
        key: 'UpdateMyPrograms',
        value: function UpdateMyPrograms() {

            _storage2.default.remove('myPrograms');
            myProgramsCache = [];

            // hole die ersten 100 ergebnisse

            getToken().then(function success(token) {
                var page = 1;
                _sendRequest(generateBodyForMyPrograms(token, page), 'https://api.affili.net/V2.0/PublisherProgram.svc', 'http://affilinet.framework.webservices/Svc/PublisherProgramContract/SearchPrograms').then(function (response) {
                    // checke ob mehr als 100
                    var xmlDoc = getXml(response);
                    var totalResults = xmlDoc.getElementsByTagName("TotalResults")[0].firstChild.nodeValue;
                    var ProgramCollection = xmlDoc.getElementsByTagName("ProgramCollection")[0];
                    var resultsOnThisPage = ProgramCollection.getElementsByTagName("a:Program").length;

                    var totalPages = Math.ceil(totalResults / 100);
                    console.log('INFO: Webservice Reports ', totalResults, ' Partnerships on ', totalPages, ' Pages.. fetching data from webserivice');

                    _fetchAllMyProgramsPages(totalPages, token, 1);
                }, console.debug);
            }, function error() {
                console.debug('in Method GetAllPrograms:error');
            });

            // wenn mehr als 100 iteriere bis maximale anzahl erreicht ist

        }
    }, {
        key: 'Reset',
        value: function Reset() {
            "use strict";

            _removeToken();
        }
    }, {
        key: 'UpdateCredentials',
        value: function UpdateCredentials(pub, pass) {
            publisherId = pub;
            webservicePassword = pass;
        }
    }]);

    return PublisherWebservice;
}();

var publisherWebservice = new PublisherWebservice();
module.exports = publisherWebservice;

},{"../utils/storage":3}],2:[function(require,module,exports){
'use strict';

var apis = ['alarms', 'bookmarks', 'browserAction', 'commands', 'contextMenus', 'cookies', 'downloads', 'events', 'extension', 'extensionTypes', 'history', 'i18n', 'idle', 'notifications', 'pageAction', 'runtime', 'storage', 'tabs', 'webNavigation', 'webRequest', 'windows'];

function Extension() {
  var _this = this;

  apis.forEach(function (api) {

    _this[api] = null;

    try {
      if (chrome[api]) {
        _this[api] = chrome[api];
      }
    } catch (e) {}

    try {
      if (window[api]) {
        _this[api] = window[api];
      }
    } catch (e) {}

    try {
      if (browser[api]) {
        _this[api] = browser[api];
      }
    } catch (e) {}
    try {
      _this.api = browser.extension[api];
    } catch (e) {}
  });

  try {
    if (browser && browser.runtime) {
      this.runtime = browser.runtime;
    }
  } catch (e) {}

  try {
    if (browser && browser.browserAction) {
      this.browserAction = browser.browserAction;
    }
  } catch (e) {}
}

/**
 * @typedef {Object} FooEngine
 * @property {function(string, boolean)} start Starts the [Foo/Bar] Engine
 */

/**
 * The Browser Extensions
 * @typedef {Object} Extension
 * @proptery {function} alarms
 * @proptery {function} bookmarks
 * @proptery {function} browserAction
 * @proptery {function} commands
 * @proptery {function} contextMenus
 * @proptery {function} cookies
 * @proptery {function} downloads
 * @proptery {function} events
 * @proptery {function} extension
 * @proptery {function} extensionTypes
 * @proptery {function} history
 * @proptery {function} i18n
 * @proptery {function} idle
 * @proptery {function} notifications
 * @proptery {function} pageAction
 * @proptery {function} runtime
 * @proptery {function} storage
 * @proptery {function} tabs
 * @proptery {function} webNavigation
 * @proptery {function} webRequest
 * @proptery {function} windows
 */

var ext = new Extension();

module.exports = ext;

},{}],3:[function(require,module,exports){
"use strict";

var _ext = require("./ext");

var _ext2 = _interopRequireDefault(_ext);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 *  * @typedef chrome.storage.local storage
 */
var storage = _ext2.default.storage.local;
module.exports = storage;

},{"./ext":2}]},{},[1])

//# sourceMappingURL=publisherWebservice.js.map
