(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

var _ext = require("./utils/ext");

var _ext2 = _interopRequireDefault(_ext);

var _storage = require("./utils/storage");

var _storage2 = _interopRequireDefault(_storage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Content Script ist loaded into ALL TABS
 *
 */

function initContextMenu() {
    var contextMenuIsOpened = false;
    var currentImage = null;

    var successMessageTimeout = null;
    var hoverImageContainer = createHoverImageContainer();
    var contextMenu = createContextMenu();
    var currentPageHasProgramPartnershipAndDeeplink = false;

    hoverImageContainer.appendChild(contextMenu);
    hoverImageContainer.addEventListener('click', openContextMenu);

    contextMenu.addEventListener('click', onContextMenuClick);

    // close context menu on escape key
    window.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closeContextMenu();
        }
    });

    // listener for messages from backgroundpage

    _ext2.default.runtime.sendMessage({ action: "hasProgramPartnershipAndDeeplink" }, function (response) {
        hasProgramPartnershipAndDeeplink(response);
    });

    function hasProgramPartnershipAndDeeplink(value) {
        currentPageHasProgramPartnershipAndDeeplink = value;
        if (value === true) {
            document.getElementById('affilinet-webext-copy-codes-headline').classList.remove('affilinet-webext-hidden');
            document.getElementById('affilinet-webext-copy-codes').classList.remove('affilinet-webext-hidden');
        } else {
            document.getElementById('affilinet-webext-copy-codes-headline').classList.add('affilinet-webext-hidden');
            document.getElementById('affilinet-webext-copy-codes').classList.add('affilinet-webext-hidden');
        }
    }

    function createHoverImageContainer() {
        var iconURL = _ext2.default.extension.getURL('icons/icon-16.png');
        var hoverImageContainer = document.createElement('div');
        hoverImageContainer.id = 'affilinet-webext-imageHoverBtn';
        var img = document.createElement('img');
        img.id = 'affilinet-webext-image';
        img.src = iconURL;
        hoverImageContainer.appendChild(img);
        return hoverImageContainer;
    }

    function createContextMenu() {
        var contextmenu = document.createElement('div');
        contextmenu.id = 'affilinet-webext-contextmenu';

        /**
         * No unsafe strings are passed to innerHTML
         */
        contextmenu.innerHTML = '<div class="affilinet-webext-row" style="margin-bottom:0 !important;"><img id="affilinet-webext-close" data-target="close" src="' + _ext2.default.extension.getURL('images/fa-close.gif') + '"></div>' + '' + '<div class="affilinet-webext-row"> <p>' + _ext2.default.i18n.getMessage('context_shareOn') + '</p></div>' + '<div class="affilinet-webext-row">' + '<img class="affilinet-webext-share" data-target="pinterest" src="' + _ext2.default.extension.getURL('images/fa-pinterest.gif') + '">' + '<img class="affilinet-webext-share" data-target="facebook" src="' + _ext2.default.extension.getURL('images/fa-facebook.gif') + '">' + '<img class="affilinet-webext-share" data-target="google" src="' + _ext2.default.extension.getURL('images/fa-google.gif') + '">' + '<img class="affilinet-webext-share" data-target="twitter" src="' + _ext2.default.extension.getURL('images/fa-twitter-square.gif') + '">' + '</div>' + '<div class="affilinet-webext-row"> <p>' + _ext2.default.i18n.getMessage('context_likeList') + '</p></div>' + '<div class="affilinet-webext-row">' + '<img class="affilinet-webext-save" data-target="image" src="' + _ext2.default.extension.getURL('images/fa-camera.gif') + '">' + '<img class="affilinet-webext-save" data-target="link" src="' + _ext2.default.extension.getURL('images/fa-globe.gif') + '">' + '</div>' + '<div class="affilinet-webext-row affilinet-webext-hidden" id="affilinet-webext-copy-codes-headline"> <p>' + _ext2.default.i18n.getMessage('context_codes') + '</p></div>' + '<div class="affilinet-webext-row affilinet-webext-hidden" id="affilinet-webext-copy-codes">' + '<img class="affilinet-webext-code" data-target="copyImageCode" src="' + _ext2.default.extension.getURL('images/fa-code.gif') + '">' + '<img class="affilinet-webext-deeplink" data-target="copyDeeplink" src="' + _ext2.default.extension.getURL('images/fa-link.gif') + '">' + '</div>' + '<div class="affilinet-webext-row">' + '<div id="affilinet-webext-success-message" class="affilinet-webext-hidden"></div>' + '</div>';
        return contextmenu;
    }

    function openContextMenu(event) {
        event.stopPropagation();
        event.preventDefault();
        contextMenu.style.display = 'block';
        document.addEventListener('click', closeContextMenu);
        contextMenuIsOpened = true;
    }

    function onContextMenuClick(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.dataset.target) {
            switch (event.target.dataset.target) {
                case 'close':
                    closeContextMenu();
                    break;
                case 'image':
                    saveImage();
                    break;
                case 'link':
                    saveLink();
                    break;
                case 'copyDeeplink':
                    copyDeeplink();
                    break;
                case 'copyImageCode':
                    copyImageCode();
                    break;
                case 'pinterest':
                case 'facebook':
                case 'google':
                case 'twitter':
                    shareOn(event.target.dataset.target);
                    break;
            }
        }
        return false;
    }

    function copyDeeplink() {
        console.log('copy deeplink');

        _ext2.default.runtime.sendMessage({
            action: "copyDeeplink",
            data: getShareDetails()
        }, function (response) {
            showSuccessMessage(response, _ext2.default.i18n.getMessage('context_messageDeeplinkCopied'));
        });
    }
    function copyImageCode() {
        console.log('copy image code');
        _ext2.default.runtime.sendMessage({
            action: "copyImageCode",
            data: getShareDetails()
        }, function (response) {
            showSuccessMessage(response, _ext2.default.i18n.getMessage('context_messageImageCodeCopied'));
        });
    }

    function closeContextMenu() {
        if (contextMenuIsOpened) {
            contextMenu.style.display = 'none';
            contextMenuIsOpened = false;
            document.removeEventListener('click', closeContextMenu);
            document.getElementById('affilinet-webext-success-message').innerText = '';
            document.getElementById('affilinet-webext-success-message').classList.add('affilinet-webext-hidden');
        }
    }

    function shareOn(socialNetworkName) {
        _ext2.default.runtime.sendMessage({
            action: "share-on-" + socialNetworkName,
            data: getShareDetails()
        });
        closeContextMenu();
    }

    function saveImage() {
        var details = getShareDetails();
        details.type = 'image';
        _ext2.default.runtime.sendMessage({
            action: "save-in-like-list",
            data: details
        }, function (response) {
            showSuccessMessage(response, _ext2.default.i18n.getMessage('context_messageImageSaved'));
        });
    }

    function saveLink() {
        var details = getShareDetails();
        details.type = 'link';
        _ext2.default.runtime.sendMessage({
            action: "save-in-like-list",
            data: details
        }, function (response) {
            showSuccessMessage(response, _ext2.default.i18n.getMessage('context_messageWebsiteSaved'));
        });
    }

    function showSuccessMessage(response, message) {
        console.log('RESPONSE', response);
        document.getElementById('affilinet-webext-success-message').innerText = message;
        document.getElementById('affilinet-webext-success-message').classList.remove('affilinet-webext-hidden');
    }
    function getShareDetails() {
        return {
            image: {
                src: currentImage.src,
                width: currentImage.width,
                height: currentImage.height,
                alt: currentImage.alt,
                title: currentImage.title
            },
            uri: window.location.toString(),
            hasDeeplink: currentPageHasProgramPartnershipAndDeeplink,
            pageTitle: document.title,
            createdAt: +new Date()
        };
    }

    function positionHoverImage(boundingEdges) {
        var top = boundingEdges.top + boundingEdges.height + window.pageYOffset - 26;
        var left = boundingEdges.left + boundingEdges.width + window.pageXOffset - 26;
        hoverImageContainer.style.top = top + 'px';
        hoverImageContainer.style.left = left + 'px';
    }

    function showHoverImage() {
        hoverImageContainer.style.display = 'block';
    }

    function hideHoverImage() {
        hoverImageContainer.style.display = 'none';
    }

    function onImageMouseEnter() {
        if (contextMenuIsOpened) {
            return;
        }
        currentImage = this;
        positionHoverImage(this.getBoundingClientRect());
        showHoverImage();
    }

    function onImageMouseLeave(event) {
        if (event.toElement && event.toElement.id.search('affilinet-webext') === 0 || contextMenuIsOpened) {
            return true;
        } else {
            hideHoverImage();
        }
    }

    function addListenersToAllImages() {
        var images = document.images;
        for (var i = 0; i < images.length; i++) {
            // only add listener to images wider or taller than 50 px
            if (images[i].width > 50 && images[i].height > 50) {
                images[i].addEventListener('mouseenter', onImageMouseEnter);
                images[i].addEventListener('mouseleave', onImageMouseLeave);
            }
        }
    }

    addListenersToAllImages();
    document.body.appendChild(hoverImageContainer);
    // images.addEventListener('change' , console.info('changed images'));


    var target = document.body;

    // create an observer instance
    var observer = new MutationObserver(function (mutations) {
        addListenersToAllImages();
    });

    // configuration of the observer , only when nodes are added
    var config = { attributes: false, childList: true, characterData: false };

    // pass in the target node, as well as the observer options
    observer.observe(target, config);
}

function detectWordpressPluginAdminPage() {
    if (window.location.toString().indexOf('wp-admin') > -1) {

        // open widgets page when clicking on the button
        var buttons = document.getElementsByClassName('affilinet-browser-extension-open-widgets-page-on-click');

        for (var i = 0; i < buttons.length; i++) {
            buttons[i].addEventListener('click', function () {
                _ext2.default.runtime.sendMessage({ action: "open-page", data: { page: "widget" } });
            });
        }

        // open settingspage event listener
        document.addEventListener("affilinet-browser-extension-open-widgets", function (e) {

            var data = { page: 'widget' };
            if (e.detail && e.detail.widgetId) {
                data.page = 'widget?widgetId=' + e.detail.widgetId;
            }
            _ext2.default.runtime.sendMessage({ action: "open-page", data: data });
        });

        document.getElementsByClassName('wp-admin')[0].classList.add('affilinet-browser-extension-installed');
    }
}

(function () {
    _storage2.default.get('disableImageContextMenu', function (result) {
        if (result.disableImageContextMenu !== true) {
            initContextMenu();
        }
    });
    // detect Wordpress plugin settings page
    detectWordpressPluginAdminPage();
})();

},{"./utils/ext":2,"./utils/storage":3}],2:[function(require,module,exports){
'use strict';

var apis = ['alarms', 'bookmarks', 'browserAction', 'commands', 'contextMenus', 'cookies', 'downloads', 'events', 'extension', 'extensionTypes', 'history', 'i18n', 'idle', 'notifications', 'pageAction', 'runtime', 'storage', 'tabs', 'webNavigation', 'webRequest', 'windows'];

function Extension() {
  var _this = this;

  apis.forEach(function (api) {

    _this[api] = null;

    try {
      if (chrome[api]) {
        _this[api] = chrome[api];
      }
    } catch (e) {}

    try {
      if (window[api]) {
        _this[api] = window[api];
      }
    } catch (e) {}

    try {
      if (browser[api]) {
        _this[api] = browser[api];
      }
    } catch (e) {}
    try {
      _this.api = browser.extension[api];
    } catch (e) {}
  });

  try {
    if (browser && browser.runtime) {
      this.runtime = browser.runtime;
    }
  } catch (e) {}

  try {
    if (browser && browser.browserAction) {
      this.browserAction = browser.browserAction;
    }
  } catch (e) {}
}

/**
 * @typedef {Object} FooEngine
 * @property {function(string, boolean)} start Starts the [Foo/Bar] Engine
 */

/**
 * The Browser Extensions
 * @typedef {Object} Extension
 * @proptery {function} alarms
 * @proptery {function} bookmarks
 * @proptery {function} browserAction
 * @proptery {function} commands
 * @proptery {function} contextMenus
 * @proptery {function} cookies
 * @proptery {function} downloads
 * @proptery {function} events
 * @proptery {function} extension
 * @proptery {function} extensionTypes
 * @proptery {function} history
 * @proptery {function} i18n
 * @proptery {function} idle
 * @proptery {function} notifications
 * @proptery {function} pageAction
 * @proptery {function} runtime
 * @proptery {function} storage
 * @proptery {function} tabs
 * @proptery {function} webNavigation
 * @proptery {function} webRequest
 * @proptery {function} windows
 */

var ext = new Extension();

module.exports = ext;

},{}],3:[function(require,module,exports){
"use strict";

var _ext = require("./ext");

var _ext2 = _interopRequireDefault(_ext);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 *  * @typedef chrome.storage.local storage
 */
var storage = _ext2.default.storage.local;
module.exports = storage;

},{"./ext":2}]},{},[1])

//# sourceMappingURL=contentscript.js.map
