(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

var _ext = require("./utils/ext");

var _ext2 = _interopRequireDefault(_ext);

var _storage = require("./utils/storage");

var _storage2 = _interopRequireDefault(_storage);

var _publisherWebservice = require("../scripts/services/publisherWebservice");

var _publisherWebservice2 = _interopRequireDefault(_publisherWebservice);

var _papaparse = require("../scripts/services/papaparse.min");

var _papaparse2 = _interopRequireDefault(_papaparse);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var settingsPageTabId = null;
var currentPageProgramDetails = [];
var globalHasPartnership = false;
var globalHasProgram = false;
var globalHasProgramPartnerShipAndDeeplink = false;

var linkShortener = 'https://productwidget.com/api/v1.0/shortlink';

_ext2.default.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    console.log('message received', request);
    switch (request.action) {
        case "open-popup":
            console.log(request.data.tabs);
            break;
        case "update-programData":
            forceUpdateData();
            break;
        case "open-page":
            openPage(request.data.page);
            break;

        case "copyImageCode":
            copyImageCode(request.data, sendResponse);

            break;
        case "copyDeeplink":
            generateTrackingUrl(request.data.uri).then(function (deeplink) {
                console.log('copy deeplink', deeplink);
                _copyTextToClipboard(deeplink);
                sendResponse(true);
            });
            break;

        case "shorten-link":
            shortenLink(request.data.link, sendResponse);
            break;

        case "hasProgramPartnershipAndDeeplink":
            sendResponse(globalHasProgramPartnerShipAndDeeplink);
            break;
        case "save-in-like-list":
            _saveInLikeList(request.data, sendResponse);
            break;

        case "share-on-twitter":
            return generateTrackingUrl(request.data.uri).then(function (redirectUrl) {
                console.log('redirect url = ', redirectUrl);
                var url = 'https://twitter.com/share?url=' + encodeURIComponent(redirectUrl) + '&text=' + encodeURIComponent(request.data.pageTitle);
                _ext2.default.tabs.create({ url: url });
            });

        case "share-on-facebook":
            return generateTrackingUrl(request.data.uri).then(function (redirectUrl) {
                var url = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(redirectUrl);
                _ext2.default.tabs.create({ url: url });
            });
        case "share-on-pinterest":
            return generateTrackingUrl(request.data.uri).then(function (redirectUrl) {
                var url = 'https://pinterest.com/pin/create/bookmarklet/?media=' + encodeURIComponent(request.data.image.src) + '&url=' + encodeURIComponent(redirectUrl) + '&description=' + encodeURIComponent(request.data.pageTitle);
                _ext2.default.tabs.create({ url: url });
            });
        case "share-on-google":
            return generateTrackingUrl(request.data.uri).then(function (redirectUrl) {
                var url = 'https://plus.google.com/share?url=' + encodeURIComponent(redirectUrl);
                _ext2.default.tabs.create({ url: url });
            });
        case "open-link":
            _ext2.default.tabs.create({ url: request.data.link });
            break;
        case 'clear-cache':
            console.log('received clear cache');
            _publisherWebservice2.default.Reset();
            break;

        case 'save-current-tab-in-like-list':
            return _saveCurrentTabInLikeList(sendResponse);
            break;

        case 'get-programDetails':
            _ext2.default.tabs.query({ active: true, currentWindow: true }, function (arrayOfTabs) {

                // since only one tab should be active and in the current window at once
                // the return variable should only have one entry
                var activeTab = arrayOfTabs[0];
                hasProgram(getCleanedHostnameforUrl(activeTab.url)).then(function (programDetails) {
                    sendResponse({ programDetails: programDetails });
                }, function (error) {
                    sendResponse({ programDetails: false });
                });
            });
            break;
        case 'get-programDetailsForProgramId':
            getDetailsForProgramId(request.data.programId).then(function (programDetails) {
                sendResponse(programDetails);
            }, function (error) {
                sendResponse(false);
            });
            return true;
            break;

        case 'save-credentials':
            console.log('received save credentials');
            _publisherWebservice2.default.UpdateCredentials(request.data.publisherId, request.data.webservicePassword);
            _storage2.default.set({
                publisherId: request.data.publisherId,
                webservicePassword: request.data.webservicePassword,
                countryPlatform: request.data.countryPlatform,
                disableImageContextMenu: request.data.disableImageContextMenu,
                productWebservicePassword: request.data.productWebservicePassword
            });
            // reload all programs
            _publisherWebservice2.default.Reset();
            _publisherWebservice2.default.UpdateMyPrograms();
            _publisherWebservice2.default.GetPublisherSummary().then(function (publisherSummary) {
                updatePublisherSummary(publisherSummary);
            }, function (error) {
                return console.debug(error);
            });

            forceUpdateData();

            break;
    }
    return true;
});

function copyImageCode(data, sendResponse) {
    generateTrackingUrl(data.uri).then(function (deeplink) {
        var code = '<a href="' + deeplink + '" target="_blank" rel="nofollow"><img src="' + data.image.src + '"></a>';
        console.log('copy image code', code);
        _copyTextToClipboard(code);
        sendResponse(true);
    });
}
function _saveCurrentTabInLikeList(sendResponse) {
    console.log('in _saveCurrentTabInLikeList ');

    _ext2.default.tabs.query({ active: true, currentWindow: true }, function (arrayOfTabs) {

        // since only one tab should be active and in the current window at once
        // the return variable should only have one entry
        var activeTab = arrayOfTabs[0];
        console.log(activeTab);

        var data = {
            image: {
                src: activeTab.favIconUrl,
                width: 16,
                height: 16,
                alt: activeTab.title,
                title: activeTab.title
            },
            type: 'link',
            uri: activeTab.url,
            pageTitle: activeTab.title,
            createdAt: +new Date()
        };
        _saveInLikeList(data, sendResponse);
    });
}

function _saveInLikeList(data, sendResponse) {
    _storage2.default.get('likeList', function (result) {
        var list = [];
        if (result.likeList) {
            list = result.likeList;
        }
        list.push(data);
        _storage2.default.set({ likeList: list });
        sendResponse({ message: 'Added to LikeList' });
    });
}

function generateTrackingUrl(url) {

    return new Promise(function (resolve, reject) {
        hasProgram(getCleanedHostnameforUrl(url)).then(function (programDetails) {
            if (programDetails === false) {
                resolve(url);
            } else {
                hasPartnership(programDetails.programId).then(function (hasPartnershipResult) {
                    if (hasPartnershipResult === true) {
                        hasDeeplink(programDetails.programId).then(function (result) {
                            if (result.deeplinkInfo === false || result.publisherId === null) {
                                resolve(url);
                            } else {
                                resolve(generateDeeplink(url, result.publisherId, result.deeplinkInfo));
                            }
                        });
                    } else {
                        resolve(url);
                    }
                });
            }
        });
    });
}

function shortenLink(url, sendResponse) {

    var xhr = new XMLHttpRequest();
    xhr.open('POST', linkShortener);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function () {
        if (xhr.status === 200) {
            var linkInfo = JSON.parse(xhr.responseText);
            sendResponse(linkInfo.link);
        } else {
            sendResponse(false);
        }
    };
    xhr.send(JSON.stringify({
        link: url
    }));
}

function generateDeeplink(url, publisherId, deeplinkInfo) {

    console.log('in gen deeplink', url, publisherId, deeplinkInfo);
    var params = deeplinkInfo.params;

    var trackingLink = deeplinkInfo.trackingLink;
    // do not just append the parameters, we might have a URI Hash
    var deeplinkParser = document.createElement('a');
    deeplinkParser.href = url;

    // parameter forwarding
    if (params !== '') {
        if (deeplinkParser.search.indexOf('?') === -1) {
            deeplinkParser.search += '?' + params;
        } else {
            deeplinkParser.search += '&' + params;
        }
    }
    var finalUrl = deeplinkParser.href;

    // redirect form tracking url to attribution solution?
    if (deeplinkInfo.hasOwnProperty('redirector')) {
        if (deeplinkInfo.redirector !== '') {
            // do not directly redirect to advertiser
            finalUrl = deeplinkInfo.redirector + encodeURIComponent(finalUrl);
        }
    }

    trackingLink = trackingLink.replace('[deeplink]', encodeURIComponent(finalUrl));
    trackingLink = trackingLink.replace('[ref]', publisherId);
    trackingLink = trackingLink.replace('[paramforwarding]', '');
    return trackingLink;
}

function _copyTextToClipboard(text) {
    var copyFrom = document.createElement("textarea");
    copyFrom.textContent = text;
    var body = document.body;
    body.appendChild(copyFrom);
    copyFrom.select();
    document.execCommand('copy');
    body.removeChild(copyFrom);
}

/**
 * * Listener on tab close if settings page is opened  - workaround for edge
 * @param tabId
 */
var onSettingsPageTabClose = function onSettingsPageTabClose(tabId) {
    if (tabId === settingsPageTabId) {
        settingsPageTabId = null;
        _ext2.default.tabs.onRemoved.removeListener(onSettingsPageTabClose);
        _ext2.default.tabs.onUpdated.removeListener(onSettingsPageTabUpdated);
    }
};

/**
 * Listener on tab changes if settings page is opened  - workaround for edge
 * @param tabId
 * @param changeInfo
 */
var onSettingsPageTabUpdated = function onSettingsPageTabUpdated(tabId, changeInfo) {
    if (tabId === settingsPageTabId) {
        if (changeInfo.url && changeInfo.url.indexOf(_ext2.default.extension.getURL('')) === -1) {
            // settings page tab.. url changed to other domain (not showing settings page anymore)
            settingsPageTabId = null;
            _ext2.default.tabs.onUpdated.removeListener(onSettingsPageTabUpdated);
            _ext2.default.tabs.onRemoved.removeListener(onSettingsPageTabClose);
        }
    }
};

function openPage(page) {
    _ext2.default.windows.getCurrent(function (currentWindow, test) {
        if (settingsPageTabId === null) {
            _ext2.default.tabs.create({
                url: _ext2.default.extension.getURL('/settings-page/index.html#' + page)
            }, function (tab) {

                settingsPageTabId = tab.id;
                _ext2.default.tabs.onUpdated.addListener(onSettingsPageTabUpdated);
                _ext2.default.tabs.onRemoved.addListener(onSettingsPageTabClose);
            });
        } else {
            // move the tab to current window and make it active
            _ext2.default.tabs.move(settingsPageTabId, {
                windowId: _ext2.default.windows.WINDOW_ID_CURRENT,
                index: -1
            }, function (window) {
                _ext2.default.tabs.update(settingsPageTabId, {
                    url: _ext2.default.extension.getURL('/settings-page/index.html#' + page),
                    active: true
                }, function (tab) {});
            });
        }
    });
}

var updateStatisticsInPopup = function updateStatisticsInPopup(current, open, cancelled) {
    _ext2.default.runtime.sendMessage({ action: "popup-stats", data: { current: current, open: open, cancelled: cancelled } });
};

/**
 * @tdodo move to a service class
 * @param string
 * @returns {Document}
 */
function getXml(string) {
    var parser = new DOMParser();
    return parser.parseFromString(string, "application/xml");
}

function updatePublisherSummary(apiResponseString) {
    var xmlDoc = getXml(apiResponseString);

    var root = xmlDoc.getElementsByTagName('PublisherSummary')[0];
    var CurrentMonth = root.getElementsByTagName("a:CurrentMonth")[0];

    if (typeof CurrentMonth !== 'undefined') {

        var confirmed = CurrentMonth.getElementsByTagName("a:Confirmed")[0].firstChild.nodeValue;
        var open = CurrentMonth.getElementsByTagName("a:Open")[0].firstChild.nodeValue;
        var cancelled = CurrentMonth.getElementsByTagName("a:Cancelled")[0].firstChild.nodeValue;

        _publisherWebservice2.default.GetLinkedAccounts().then(function (linkedAccountsResponse) {

            var linkedAccountsRoot = getXml(linkedAccountsResponse);
            var currency = linkedAccountsRoot.getElementsByTagName('a:Currency')[0].firstChild.nodeValue;
            var loc = 'de-DE';

            if (currency === null || currency === undefined) {
                currency = 'EUR';
            } else if (currency === 'GBP') {
                loc = 'en-gb';
            } else if (currency === 'CHF') {
                loc = 'de-ch';
            }

            if (confirmed === undefined) {
                confirmed = ' ';
            } else {
                confirmed = parseFloat(confirmed).toLocaleString(loc, {
                    localeMatcher: 'best fit',
                    style: 'currency',
                    currency: currency
                });
            }
            if (open === undefined) {
                open = ' ';
            } else {
                open = parseFloat(open).toLocaleString(loc, {
                    localeMatcher: 'best fit',
                    style: 'currency',
                    currency: currency
                });
            }
            if (cancelled === undefined) {
                cancelled = ' ';
            } else {
                cancelled = parseFloat(cancelled).toLocaleString(loc, {
                    localeMatcher: 'best fit',
                    style: 'currency',
                    currency: currency
                });
            }

            updateStatisticsInPopup(confirmed, open, cancelled);
            _storage2.default.set({
                confirmed: confirmed,
                open: open,
                cancelled: cancelled,
                ApiLocale: loc,
                Currency: currency
            });
        }, console.error);
    }
}

/**
 * Extract the hostname from an URI
 * @param string
 */
function getCleanedHostnameforUrl(string) {
    var parser = document.createElement('a');
    parser.href = string;
    var host = parser.host.replace('www.', '');
    return '//' + host;
}

/**
 *  Show if  there is a partnership with the current URI- host
 *
 * @param hasPartnership
 * @param tabId
 */
function setHasPartnership(hasPartnership, tabId) {
    if (hasPartnership) {
        globalHasPartnership = true;
        _ext2.default.browserAction.setBadgeBackgroundColor({ color: '#007239', tabId: tabId });
    } else {
        globalHasPartnership = false;
        globalHasProgramPartnerShipAndDeeplink = false;
        _ext2.default.browserAction.setBadgeBackgroundColor({ color: '#DE1C44', tabId: tabId });
    }
}

/**
 * Show if the current URI has a affilinet Advertiser Program
 *
 * @param hasProgram
 * @param tabId
 */
function setHasProgram(hasProgram, tabId) {
    if (hasProgram) {
        globalHasProgram = true;
        _ext2.default.browserAction.setBadgeText({ text: 'i', tabId: tabId });
    } else {
        globalHasProgram = false;
        globalHasProgramPartnerShipAndDeeplink = false;
        _ext2.default.browserAction.setBadgeText({ text: '', tabId: tabId });
    }
}

/**
 * Update the plugin Button for the hostname
 *
 * We do NOT call any API with the currently visited URL
 * Simply check if the hostname is in all known hostnames / my Programs hostnames
 *
 * @param programId
 * @param tabId
 */
function checkHostHasPartnership(programId, tabId) {
    hasPartnership(programId).then(function (hasPartnership) {
        console.log('programId hasPartnership', hasPartnership);
        setHasPartnership(hasPartnership, tabId);
        if (hasPartnership === true) {
            checkHostHasDeeplink(programId, tabId);
        }
    });
}

function hasDeeplink(programId) {
    return new Promise(function (resolve, reject) {
        _storage2.default.get(['programsWithDeeplink', 'publisherId'], function (storageResult) {
            var deeplinkInfo = storageResult.programsWithDeeplink.find(function (entry) {
                return entry.programId === programId && entry.platform !== '';
            });
            resolve({ deeplinkInfo: deeplinkInfo, publisherId: storageResult.publisherId });
        });
    });
}
function checkHostHasDeeplink(programId, tabId) {
    hasDeeplink(programId).then(function (result) {
        console.log('programId hasDeeplink', result);
        globalHasProgramPartnerShipAndDeeplink = !!result.deeplinkInfo;
    });
}

function hasProgram(hostname) {
    return new Promise(function (resolve, reject) {
        _storage2.default.get(['allPrograms', 'countryPlatform'], function (result) {
            if (!result.allPrograms) {
                resolve(false);
            } else {

                // find program in allPrograms
                var programIndex = result.allPrograms.findIndex(function (program) {
                    if (program.platformId !== result.countryPlatform) return false;
                    return hostname.endsWith('/' + program.programUrl) === true || hostname.endsWith('.' + program.programUrl) === true;
                });
                if (programIndex >= 0) {
                    resolve(result.allPrograms[programIndex]);
                } else {
                    resolve(false);
                }
            }
        });
    });
}

function getDetailsForProgramId(programId) {
    return new Promise(function (resolve, reject) {
        _storage2.default.get(['allPrograms', 'countryPlatform'], function (result) {
            if (!result.allPrograms) {
                console.error('allPrograms not loaded');
                resolve(false);
            } else {
                // find program in allPrograms
                var programIndex = result.allPrograms.findIndex(function (program) {
                    return +program.programId === +programId && program.platformId === result.countryPlatform;
                });
                if (programIndex > 0) {
                    console.log('programs found ', result.allPrograms[programIndex]);
                    resolve(result.allPrograms[programIndex]);
                } else {
                    console.error('programs not found loaded');
                    resolve(false);
                }
            }
        });
    });
}

function hasPartnership(programId) {
    return new Promise(function (resolve, rejcet) {
        _storage2.default.get(['myPrograms'], function (result) {
            if (!result.myPrograms) {
                resolve(false);
            } else {
                for (var i = 0; i < result.myPrograms.length; i++) {
                    if (result.myPrograms[i].programId === programId) {
                        resolve(true);
                        return;
                    }
                }
                resolve(false);
            }
        });
    });
}

/**
 * Hast this hostname a program?
 *
 * @param hostname
 * @param tabId
 */
function checkHostHasProgram(hostname, tabId) {
    hasProgram(hostname).then(function (programInfo) {
        console.log('hostname has program', hostname, programInfo);
        setHasProgram(programInfo, tabId);
        if (programInfo !== false) {
            checkHostHasPartnership(programInfo.programId, tabId);
        }
    });
}

/**
 * On tab open: Check for Program/Partnership
 */

_ext2.default.windows.onFocusChanged.addListener(getInfoaboutTab);
_ext2.default.tabs.onHighlighted.addListener(getInfoaboutTab);
_ext2.default.tabs.onAttached.addListener(getInfoaboutTab);

_ext2.default.tabs.onUpdated.addListener(function (tab, changes) {
    if (changes.url) {
        getInfoaboutTab();
    }
});

/**
 * Take the hostname of the URL
 * Check if this hostname is included in "myPrograms" or is included in "All Programs"
 *
 */
function getInfoaboutTab() {

    _ext2.default.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length) {
            var hostname = getCleanedHostnameforUrl(tabs[0].url);
            console.log('info about tab with hostname', hostname);
            if (hostname !== 'newtab' && hostname !== null && hostname !== '' && hostname !== getCleanedHostnameforUrl(_ext2.default.extension.getURL(''))) {
                checkHostHasProgram(hostname, tabs[0].id);
            }
        }
    });
}

function updateProgramsWithDeeplink() {
    console.log('downloading all programs with deeplink');
    _papaparse2.default.parse('https://raw.githubusercontent.com/affilinet/browser-webextension-publisher/master/resources/deeplinks.csv', {
        download: true,
        header: true,
        complete: function complete(results) {
            console.log('Updated all programsWithDeeplink');
            _storage2.default.set({
                programsWithDeeplink: results.data
            });
        }
    });
}

function updateAllPrograms() {
    console.log('downloading all programs');
    _papaparse2.default.parse("https://raw.githubusercontent.com/affilinet/browser-webextension-publisher/master/resources/programs.csv", {
        download: true,
        header: true,
        complete: function complete(results) {
            console.log('Updated all programs');
            _storage2.default.set({
                allPrograms: results.data
            });
        }
    });
}

function updateData() {
    _publisherWebservice2.default.GetPublisherSummary().then(updatePublisherSummary, console.debug);

    // all Programs and Programs with deeplinks get updated daily
    _storage2.default.get(['lastDailyDataUpdate'], function (storageResult) {
        var timestampMS = Date.now();
        if (!storageResult.lastDailyDataUpdate || storageResult.lastDailyDataUpdate < timestampMS - 24 * 60 * 60 * 1000) {
            // last update is longer ago than one day!
            forceUpdateData();
        } else {
            console.log('All Programs and Programs with deeplink is fresh; Last update was', new Date(storageResult.lastDailyDataUpdate));
            console.log('Next update of  Programs and Programs at', new Date(storageResult.lastDailyDataUpdate + 24 * 60 * 60 * 1000));
        }
    });
}
function forceUpdateData() {
    console.log('update my programs from webserice');
    _publisherWebservice2.default.UpdateMyPrograms();
    console.log('updateProgramsWithDeeplink');
    updateProgramsWithDeeplink();
    console.log('updateAllPrograms');
    updateAllPrograms();
    console.log('set lastDailyDataUpdate');
    _storage2.default.set({
        lastDailyDataUpdate: Date.now()
    });
}

/**
 * Inititally load all Programs and MyPrograms
 * Start loading 2 seconds after program start to improve browser startup speed
 */
window.setTimeout(function () {

    // update now
    forceUpdateData();

    // update data all 15 min
    setInterval(updateData, 15 * 60 * 1000); // 15 mins
}, 2000);

},{"../scripts/services/papaparse.min":2,"../scripts/services/publisherWebservice":3,"./utils/ext":4,"./utils/storage":5}],2:[function(require,module,exports){
"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/*!
	Papa Parse
	v4.3.5
	https://github.com/mholt/PapaParse
	License: MIT
*/
!function (a, b) {
	"function" == typeof define && define.amd ? define([], b) : "object" == (typeof module === "undefined" ? "undefined" : _typeof(module)) && "undefined" != typeof exports ? module.exports = b() : a.Papa = b();
}(undefined, function () {
	"use strict";
	function a(a, b) {
		b = b || {};var c = b.dynamicTyping || !1;if (r(c) && (b.dynamicTypingFunction = c, c = {}), b.dynamicTyping = c, b.worker && z.WORKERS_SUPPORTED) {
			var h = k();return h.userStep = b.step, h.userChunk = b.chunk, h.userComplete = b.complete, h.userError = b.error, b.step = r(b.step), b.chunk = r(b.chunk), b.complete = r(b.complete), b.error = r(b.error), delete b.worker, void h.postMessage({ input: a, config: b, workerId: h.id });
		}var i = null;return "string" == typeof a ? i = b.download ? new d(b) : new f(b) : a.readable === !0 && r(a.read) && r(a.on) ? i = new g(b) : (t.File && a instanceof File || a instanceof Object) && (i = new e(b)), i.stream(a);
	}function b(a, b) {
		function c() {
			"object" == (typeof b === "undefined" ? "undefined" : _typeof(b)) && ("string" == typeof b.delimiter && 1 === b.delimiter.length && z.BAD_DELIMITERS.indexOf(b.delimiter) === -1 && (j = b.delimiter), ("boolean" == typeof b.quotes || b.quotes instanceof Array) && (h = b.quotes), "string" == typeof b.newline && (k = b.newline), "string" == typeof b.quoteChar && (l = b.quoteChar), "boolean" == typeof b.header && (i = b.header));
		}function d(a) {
			if ("object" != (typeof a === "undefined" ? "undefined" : _typeof(a))) return [];var b = [];for (var c in a) {
				b.push(c);
			}return b;
		}function e(a, b) {
			var c = "";"string" == typeof a && (a = JSON.parse(a)), "string" == typeof b && (b = JSON.parse(b));var d = a instanceof Array && a.length > 0,
			    e = !(b[0] instanceof Array);if (d && i) {
				for (var g = 0; g < a.length; g++) {
					g > 0 && (c += j), c += f(a[g], g);
				}b.length > 0 && (c += k);
			}for (var h = 0; h < b.length; h++) {
				for (var l = d ? a.length : b[h].length, m = 0; m < l; m++) {
					m > 0 && (c += j);var n = d && e ? a[m] : m;c += f(b[h][n], m);
				}h < b.length - 1 && (c += k);
			}return c;
		}function f(a, b) {
			if ("undefined" == typeof a || null === a) return "";a = a.toString().replace(m, l + l);var c = "boolean" == typeof h && h || h instanceof Array && h[b] || g(a, z.BAD_DELIMITERS) || a.indexOf(j) > -1 || " " === a.charAt(0) || " " === a.charAt(a.length - 1);return c ? l + a + l : a;
		}function g(a, b) {
			for (var c = 0; c < b.length; c++) {
				if (a.indexOf(b[c]) > -1) return !0;
			}return !1;
		}var h = !1,
		    i = !0,
		    j = ",",
		    k = "\r\n",
		    l = '"';c();var m = new RegExp(l, "g");if ("string" == typeof a && (a = JSON.parse(a)), a instanceof Array) {
			if (!a.length || a[0] instanceof Array) return e(null, a);if ("object" == _typeof(a[0])) return e(d(a[0]), a);
		} else if ("object" == (typeof a === "undefined" ? "undefined" : _typeof(a))) return "string" == typeof a.data && (a.data = JSON.parse(a.data)), a.data instanceof Array && (a.fields || (a.fields = a.meta && a.meta.fields), a.fields || (a.fields = a.data[0] instanceof Array ? a.fields : d(a.data[0])), a.data[0] instanceof Array || "object" == _typeof(a.data[0]) || (a.data = [a.data])), e(a.fields || [], a.data || []);throw "exception: Unable to serialize unrecognized input";
	}function c(a) {
		function b(a) {
			var b = p(a);b.chunkSize = parseInt(b.chunkSize), a.step || a.chunk || (b.chunkSize = null), this._handle = new h(b), this._handle.streamer = this, this._config = b;
		}this._handle = null, this._paused = !1, this._finished = !1, this._input = null, this._baseIndex = 0, this._partialLine = "", this._rowCount = 0, this._start = 0, this._nextChunk = null, this.isFirstChunk = !0, this._completeResults = { data: [], errors: [], meta: {} }, b.call(this, a), this.parseChunk = function (a) {
			if (this.isFirstChunk && r(this._config.beforeFirstChunk)) {
				var b = this._config.beforeFirstChunk(a);void 0 !== b && (a = b);
			}this.isFirstChunk = !1;var c = this._partialLine + a;this._partialLine = "";var d = this._handle.parse(c, this._baseIndex, !this._finished);if (!this._handle.paused() && !this._handle.aborted()) {
				var e = d.meta.cursor;this._finished || (this._partialLine = c.substring(e - this._baseIndex), this._baseIndex = e), d && d.data && (this._rowCount += d.data.length);var f = this._finished || this._config.preview && this._rowCount >= this._config.preview;if (v) t.postMessage({ results: d, workerId: z.WORKER_ID, finished: f });else if (r(this._config.chunk)) {
					if (this._config.chunk(d, this._handle), this._paused) return;d = void 0, this._completeResults = void 0;
				}return this._config.step || this._config.chunk || (this._completeResults.data = this._completeResults.data.concat(d.data), this._completeResults.errors = this._completeResults.errors.concat(d.errors), this._completeResults.meta = d.meta), !f || !r(this._config.complete) || d && d.meta.aborted || this._config.complete(this._completeResults, this._input), f || d && d.meta.paused || this._nextChunk(), d;
			}
		}, this._sendError = function (a) {
			r(this._config.error) ? this._config.error(a) : v && this._config.error && t.postMessage({ workerId: z.WORKER_ID, error: a, finished: !1 });
		};
	}function d(a) {
		function b(a) {
			var b = a.getResponseHeader("Content-Range");return null === b ? -1 : parseInt(b.substr(b.lastIndexOf("/") + 1));
		}a = a || {}, a.chunkSize || (a.chunkSize = z.RemoteChunkSize), c.call(this, a);var d;u ? this._nextChunk = function () {
			this._readChunk(), this._chunkLoaded();
		} : this._nextChunk = function () {
			this._readChunk();
		}, this.stream = function (a) {
			this._input = a, this._nextChunk();
		}, this._readChunk = function () {
			if (this._finished) return void this._chunkLoaded();if (d = new XMLHttpRequest(), this._config.withCredentials && (d.withCredentials = this._config.withCredentials), u || (d.onload = q(this._chunkLoaded, this), d.onerror = q(this._chunkError, this)), d.open("GET", this._input, !u), this._config.downloadRequestHeaders) {
				var a = this._config.downloadRequestHeaders;for (var b in a) {
					d.setRequestHeader(b, a[b]);
				}
			}if (this._config.chunkSize) {
				var c = this._start + this._config.chunkSize - 1;d.setRequestHeader("Range", "bytes=" + this._start + "-" + c), d.setRequestHeader("If-None-Match", "webkit-no-cache");
			}try {
				d.send();
			} catch (a) {
				this._chunkError(a.message);
			}u && 0 === d.status ? this._chunkError() : this._start += this._config.chunkSize;
		}, this._chunkLoaded = function () {
			if (4 == d.readyState) {
				if (d.status < 200 || d.status >= 400) return void this._chunkError();this._finished = !this._config.chunkSize || this._start > b(d), this.parseChunk(d.responseText);
			}
		}, this._chunkError = function (a) {
			var b = d.statusText || a;this._sendError(b);
		};
	}function e(a) {
		a = a || {}, a.chunkSize || (a.chunkSize = z.LocalChunkSize), c.call(this, a);var b,
		    d,
		    e = "undefined" != typeof FileReader;this.stream = function (a) {
			this._input = a, d = a.slice || a.webkitSlice || a.mozSlice, e ? (b = new FileReader(), b.onload = q(this._chunkLoaded, this), b.onerror = q(this._chunkError, this)) : b = new FileReaderSync(), this._nextChunk();
		}, this._nextChunk = function () {
			this._finished || this._config.preview && !(this._rowCount < this._config.preview) || this._readChunk();
		}, this._readChunk = function () {
			var a = this._input;if (this._config.chunkSize) {
				var c = Math.min(this._start + this._config.chunkSize, this._input.size);a = d.call(a, this._start, c);
			}var f = b.readAsText(a, this._config.encoding);e || this._chunkLoaded({ target: { result: f } });
		}, this._chunkLoaded = function (a) {
			this._start += this._config.chunkSize, this._finished = !this._config.chunkSize || this._start >= this._input.size, this.parseChunk(a.target.result);
		}, this._chunkError = function () {
			this._sendError(b.error);
		};
	}function f(a) {
		a = a || {}, c.call(this, a);var b, d;this.stream = function (a) {
			return b = a, d = a, this._nextChunk();
		}, this._nextChunk = function () {
			if (!this._finished) {
				var a = this._config.chunkSize,
				    b = a ? d.substr(0, a) : d;return d = a ? d.substr(a) : "", this._finished = !d, this.parseChunk(b);
			}
		};
	}function g(a) {
		a = a || {}, c.call(this, a);var b = [],
		    d = !0;this.stream = function (a) {
			this._input = a, this._input.on("data", this._streamData), this._input.on("end", this._streamEnd), this._input.on("error", this._streamError);
		}, this._nextChunk = function () {
			b.length ? this.parseChunk(b.shift()) : d = !0;
		}, this._streamData = q(function (a) {
			try {
				b.push("string" == typeof a ? a : a.toString(this._config.encoding)), d && (d = !1, this.parseChunk(b.shift()));
			} catch (a) {
				this._streamError(a);
			}
		}, this), this._streamError = q(function (a) {
			this._streamCleanUp(), this._sendError(a.message);
		}, this), this._streamEnd = q(function () {
			this._streamCleanUp(), this._finished = !0, this._streamData("");
		}, this), this._streamCleanUp = q(function () {
			this._input.removeListener("data", this._streamData), this._input.removeListener("end", this._streamEnd), this._input.removeListener("error", this._streamError);
		}, this);
	}function h(a) {
		function b() {
			if (x && o && (l("Delimiter", "UndetectableDelimiter", "Unable to auto-detect delimiting character; defaulted to '" + z.DefaultDelimiter + "'"), o = !1), a.skipEmptyLines) for (var b = 0; b < x.data.length; b++) {
				1 === x.data[b].length && "" === x.data[b][0] && x.data.splice(b--, 1);
			}return c() && d(), g();
		}function c() {
			return a.header && 0 === w.length;
		}function d() {
			if (x) {
				for (var a = 0; c() && a < x.data.length; a++) {
					for (var b = 0; b < x.data[a].length; b++) {
						w.push(x.data[a][b]);
					}
				}x.data.splice(0, 1);
			}
		}function e(b) {
			return a.dynamicTypingFunction && void 0 === a.dynamicTyping[b] && (a.dynamicTyping[b] = a.dynamicTypingFunction(b)), (a.dynamicTyping[b] || a.dynamicTyping) === !0;
		}function f(a, b) {
			return e(a) ? "true" === b || "TRUE" === b || "false" !== b && "FALSE" !== b && k(b) : b;
		}function g() {
			if (!x || !a.header && !a.dynamicTyping) return x;for (var b = 0; b < x.data.length; b++) {
				for (var c = a.header ? {} : [], d = 0; d < x.data[b].length; d++) {
					var e = d,
					    g = x.data[b][d];a.header && (e = d >= w.length ? "__parsed_extra" : w[d]), g = f(e, g), "__parsed_extra" === e ? (c[e] = c[e] || [], c[e].push(g)) : c[e] = g;
				}x.data[b] = c, a.header && (d > w.length ? l("FieldMismatch", "TooManyFields", "Too many fields: expected " + w.length + " fields but parsed " + d, b) : d < w.length && l("FieldMismatch", "TooFewFields", "Too few fields: expected " + w.length + " fields but parsed " + d, b));
			}return a.header && x.meta && (x.meta.fields = w), x;
		}function h(b, c, d) {
			for (var e, f, g, h = [",", "\t", "|", ";", z.RECORD_SEP, z.UNIT_SEP], j = 0; j < h.length; j++) {
				var k = h[j],
				    l = 0,
				    m = 0,
				    n = 0;g = void 0;for (var o = new i({ delimiter: k, newline: c, preview: 10 }).parse(b), p = 0; p < o.data.length; p++) {
					if (d && 1 === o.data[p].length && 0 === o.data[p][0].length) n++;else {
						var q = o.data[p].length;m += q, "undefined" != typeof g ? q > 1 && (l += Math.abs(q - g), g = q) : g = q;
					}
				}o.data.length > 0 && (m /= o.data.length - n), ("undefined" == typeof f || l < f) && m > 1.99 && (f = l, e = k);
			}return a.delimiter = e, { successful: !!e, bestDelimiter: e };
		}function j(a) {
			a = a.substr(0, 1048576);var b = a.split("\r"),
			    c = a.split("\n"),
			    d = c.length > 1 && c[0].length < b[0].length;if (1 === b.length || d) return "\n";for (var e = 0, f = 0; f < b.length; f++) {
				"\n" === b[f][0] && e++;
			}return e >= b.length / 2 ? "\r\n" : "\r";
		}function k(a) {
			var b = q.test(a);return b ? parseFloat(a) : a;
		}function l(a, b, c, d) {
			x.errors.push({ type: a, code: b, message: c, row: d });
		}var m,
		    n,
		    o,
		    q = /^\s*-?(\d*\.?\d+|\d+\.?\d*)(e[-+]?\d+)?\s*$/i,
		    s = this,
		    t = 0,
		    u = !1,
		    v = !1,
		    w = [],
		    x = { data: [], errors: [], meta: {} };if (r(a.step)) {
			var y = a.step;a.step = function (d) {
				if (x = d, c()) b();else {
					if (b(), 0 === x.data.length) return;t += d.data.length, a.preview && t > a.preview ? n.abort() : y(x, s);
				}
			};
		}this.parse = function (c, d, e) {
			if (a.newline || (a.newline = j(c)), o = !1, a.delimiter) r(a.delimiter) && (a.delimiter = a.delimiter(c), x.meta.delimiter = a.delimiter);else {
				var f = h(c, a.newline, a.skipEmptyLines);f.successful ? a.delimiter = f.bestDelimiter : (o = !0, a.delimiter = z.DefaultDelimiter), x.meta.delimiter = a.delimiter;
			}var g = p(a);return a.preview && a.header && g.preview++, m = c, n = new i(g), x = n.parse(m, d, e), b(), u ? { meta: { paused: !0 } } : x || { meta: { paused: !1 } };
		}, this.paused = function () {
			return u;
		}, this.pause = function () {
			u = !0, n.abort(), m = m.substr(n.getCharIndex());
		}, this.resume = function () {
			u = !1, s.streamer.parseChunk(m);
		}, this.aborted = function () {
			return v;
		}, this.abort = function () {
			v = !0, n.abort(), x.meta.aborted = !0, r(a.complete) && a.complete(x), m = "";
		};
	}function i(a) {
		a = a || {};var b = a.delimiter,
		    c = a.newline,
		    d = a.comments,
		    e = a.step,
		    f = a.preview,
		    g = a.fastMode,
		    h = a.quoteChar || '"';if (("string" != typeof b || z.BAD_DELIMITERS.indexOf(b) > -1) && (b = ","), d === b) throw "Comment character same as delimiter";d === !0 ? d = "#" : ("string" != typeof d || z.BAD_DELIMITERS.indexOf(d) > -1) && (d = !1), "\n" != c && "\r" != c && "\r\n" != c && (c = "\n");var i = 0,
		    j = !1;this.parse = function (a, k, l) {
			function m(a) {
				x.push(a), A = i;
			}function n(b) {
				return l ? p() : ("undefined" == typeof b && (b = a.substr(i)), z.push(b), i = s, m(z), w && q(), p());
			}function o(b) {
				i = b, m(z), z = [], E = a.indexOf(c, i);
			}function p(a) {
				return { data: x, errors: y, meta: { delimiter: b, linebreak: c, aborted: j, truncated: !!a, cursor: A + (k || 0) } };
			}function q() {
				e(p()), x = [], y = [];
			}if ("string" != typeof a) throw "Input must be a string";var s = a.length,
			    t = b.length,
			    u = c.length,
			    v = d.length,
			    w = r(e);i = 0;var x = [],
			    y = [],
			    z = [],
			    A = 0;if (!a) return p();if (g || g !== !1 && a.indexOf(h) === -1) {
				for (var B = a.split(c), C = 0; C < B.length; C++) {
					var z = B[C];if (i += z.length, C !== B.length - 1) i += c.length;else if (l) return p();if (!d || z.substr(0, v) !== d) {
						if (w) {
							if (x = [], m(z.split(b)), q(), j) return p();
						} else m(z.split(b));if (f && C >= f) return x = x.slice(0, f), p(!0);
					}
				}return p();
			}for (var D = a.indexOf(b, i), E = a.indexOf(c, i), F = new RegExp(h + h, "g");;) {
				if (a[i] !== h) {
					if (d && 0 === z.length && a.substr(i, v) === d) {
						if (E === -1) return p();i = E + u, E = a.indexOf(c, i), D = a.indexOf(b, i);
					} else if (D !== -1 && (D < E || E === -1)) z.push(a.substring(i, D)), i = D + t, D = a.indexOf(b, i);else {
						if (E === -1) break;if (z.push(a.substring(i, E)), o(E + u), w && (q(), j)) return p();if (f && x.length >= f) return p(!0);
					}
				} else {
					var G = i;for (i++;;) {
						var G = a.indexOf(h, G + 1);if (G === -1) return l || y.push({ type: "Quotes", code: "MissingQuotes", message: "Quoted field unterminated", row: x.length, index: i }), n();if (G === s - 1) {
							var H = a.substring(i, G).replace(F, h);return n(H);
						}if (a[G + 1] !== h) {
							if (a[G + 1] === b) {
								z.push(a.substring(i, G).replace(F, h)), i = G + 1 + t, D = a.indexOf(b, i), E = a.indexOf(c, i);break;
							}if (a.substr(G + 1, u) === c) {
								if (z.push(a.substring(i, G).replace(F, h)), o(G + 1 + u), D = a.indexOf(b, i), w && (q(), j)) return p();if (f && x.length >= f) return p(!0);break;
							}
						} else G++;
					}
				}
			}return n();
		}, this.abort = function () {
			j = !0;
		}, this.getCharIndex = function () {
			return i;
		};
	}function j() {
		var a = document.getElementsByTagName("script");return a.length ? a[a.length - 1].src : "";
	}function k() {
		if (!z.WORKERS_SUPPORTED) return !1;if (!w && null === z.SCRIPT_PATH) throw new Error("Script path cannot be determined automatically when Papa Parse is loaded asynchronously. You need to set Papa.SCRIPT_PATH manually.");var a = z.SCRIPT_PATH || s;a += (a.indexOf("?") !== -1 ? "&" : "?") + "papaworker";var b = new t.Worker(a);return b.onmessage = l, b.id = y++, x[b.id] = b, b;
	}function l(a) {
		var b = a.data,
		    c = x[b.workerId],
		    d = !1;if (b.error) c.userError(b.error, b.file);else if (b.results && b.results.data) {
			var e = function e() {
				d = !0, m(b.workerId, { data: [], errors: [], meta: { aborted: !0 } });
			},
			    f = { abort: e, pause: n, resume: n };if (r(c.userStep)) {
				for (var g = 0; g < b.results.data.length && (c.userStep({ data: [b.results.data[g]], errors: b.results.errors, meta: b.results.meta }, f), !d); g++) {}delete b.results;
			} else r(c.userChunk) && (c.userChunk(b.results, f, b.file), delete b.results);
		}b.finished && !d && m(b.workerId, b.results);
	}function m(a, b) {
		var c = x[a];r(c.userComplete) && c.userComplete(b), c.terminate(), delete x[a];
	}function n() {
		throw "Not implemented.";
	}function o(a) {
		var b = a.data;if ("undefined" == typeof z.WORKER_ID && b && (z.WORKER_ID = b.workerId), "string" == typeof b.input) t.postMessage({ workerId: z.WORKER_ID, results: z.parse(b.input, b.config), finished: !0 });else if (t.File && b.input instanceof File || b.input instanceof Object) {
			var c = z.parse(b.input, b.config);c && t.postMessage({ workerId: z.WORKER_ID, results: c, finished: !0 });
		}
	}function p(a) {
		if ("object" != (typeof a === "undefined" ? "undefined" : _typeof(a))) return a;var b = a instanceof Array ? [] : {};for (var c in a) {
			b[c] = p(a[c]);
		}return b;
	}function q(a, b) {
		return function () {
			a.apply(b, arguments);
		};
	}function r(a) {
		return "function" == typeof a;
	}var s,
	    t = function () {
		return "undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof t ? t : {};
	}(),
	    u = !t.document && !!t.postMessage,
	    v = u && /(\?|&)papaworker(=|&|$)/.test(t.location.search),
	    w = !1,
	    x = {},
	    y = 0,
	    z = {};if (z.parse = a, z.unparse = b, z.RECORD_SEP = String.fromCharCode(30), z.UNIT_SEP = String.fromCharCode(31), z.BYTE_ORDER_MARK = "\uFEFF", z.BAD_DELIMITERS = ["\r", "\n", '"', z.BYTE_ORDER_MARK], z.WORKERS_SUPPORTED = !u && !!t.Worker, z.SCRIPT_PATH = null, z.LocalChunkSize = 10485760, z.RemoteChunkSize = 5242880, z.DefaultDelimiter = ",", z.Parser = i, z.ParserHandle = h, z.NetworkStreamer = d, z.FileStreamer = e, z.StringStreamer = f, z.ReadableStreamStreamer = g, t.jQuery) {
		var A = t.jQuery;A.fn.parse = function (a) {
			function b() {
				if (0 === f.length) return void (r(a.complete) && a.complete());var b = f[0];if (r(a.before)) {
					var e = a.before(b.file, b.inputElem);if ("object" == (typeof e === "undefined" ? "undefined" : _typeof(e))) {
						if ("abort" === e.action) return void c("AbortError", b.file, b.inputElem, e.reason);if ("skip" === e.action) return void d();"object" == _typeof(e.config) && (b.instanceConfig = A.extend(b.instanceConfig, e.config));
					} else if ("skip" === e) return void d();
				}var g = b.instanceConfig.complete;b.instanceConfig.complete = function (a) {
					r(g) && g(a, b.file, b.inputElem), d();
				}, z.parse(b.file, b.instanceConfig);
			}function c(b, c, d, e) {
				r(a.error) && a.error({ name: b }, c, d, e);
			}function d() {
				f.splice(0, 1), b();
			}var e = a.config || {},
			    f = [];return this.each(function (a) {
				var b = "INPUT" === A(this).prop("tagName").toUpperCase() && "file" === A(this).attr("type").toLowerCase() && t.FileReader;if (!b || !this.files || 0 === this.files.length) return !0;for (var c = 0; c < this.files.length; c++) {
					f.push({ file: this.files[c], inputElem: this, instanceConfig: A.extend({}, e) });
				}
			}), b(), this;
		};
	}return v ? t.onmessage = o : z.WORKERS_SUPPORTED && (s = j(), document.body ? document.addEventListener("DOMContentLoaded", function () {
		w = !0;
	}, !0) : w = !0), d.prototype = Object.create(c.prototype), d.prototype.constructor = d, e.prototype = Object.create(c.prototype), e.prototype.constructor = e, f.prototype = Object.create(f.prototype), f.prototype.constructor = f, g.prototype = Object.create(c.prototype), g.prototype.constructor = g, z;
});

},{}],3:[function(require,module,exports){
'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _storage = require('../utils/storage');

var _storage2 = _interopRequireDefault(_storage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var publisherId = null;
var webservicePassword = null;

_storage2.default.get('publisherId', function (results) {
    publisherId = results['publisherId'] || null;
});
_storage2.default.get('webservicePassword', function (results) {
    webservicePassword = results['webservicePassword'] || null;
});

var myProgramsCache = [];

var token = false;
var validUntil = false;

function getXml(string) {
    var parser = new DOMParser();
    var document = parser.parseFromString(string, "application/xml");
    if (_hasParseError(document)) {
        console.error('XML PARSER ERROR: Could not parse Response from Webservice', document);
        console.error(string);
    }
    return document;
}

/**
 * https://stackoverflow.com/questions/11563554/how-do-i-detect-xml-parsing-errors-when-using-javascripts-domparser-in-a-cross
 * Note this might not work on IE
 * @param parsedDocument
 * @returns {boolean}
 * @private
 */
function _hasParseError(parsedDocument) {
    // parser and parsererrorNS could be cached on startup for efficiency
    var parser = new DOMParser(),
        errorneousParse = parser.parseFromString('<', 'text/xml'),
        parsererrorNS = errorneousParse.getElementsByTagName("parsererror")[0].namespaceURI;

    if (parsererrorNS === 'http://www.w3.org/1999/xhtml') {
        // In PhantomJS the parseerror element doesn't seem to have a special namespace, so we are just guessing here :(
        return parsedDocument.getElementsByTagName("parsererror").length > 0;
    }
    return parsedDocument.getElementsByTagNameNS(parsererrorNS, 'parsererror').length > 0;
}

function _sendRequest(requestBody, url, soap_action) {
    return new Promise(function (resolve, reject) {
        console.log('new xhr', url, soap_action);
        var xhr = new XMLHttpRequest();

        xhr.onloadend = function (event) {
            if (xhr.status === 200) {
                resolve(xhr.responseText);
            } else {
                console.debug('ERROR response with status ' + xhr.status);
                console.debug(xhr.response);
                reject(xhr);
            }
        };
        xhr.open('post', url); // event listeners musst be attached before!
        xhr.setRequestHeader("SOAPAction", soap_action);
        xhr.setRequestHeader('Content-Type', 'text/xml; charset=utf-8');
        xhr.send(requestBody);
    });
}

var _tokenMustBeRefreshed = function _tokenMustBeRefreshed() {
    // Refresh token 2 minutes before it is invalid
    var now = Math.floor(Date.now()) + 2 * 60 * 1000;
    console.log('token is  valid  for another ', (validUntil - now) / 1000, ' seconds');
    if (token === false) {
        console.log('token is not set');
        return true;
    }
    return validUntil === false || validUntil < now;
};

var getToken = function getToken() {
    return new Promise(function (resolve, reject) {
        "use strict";

        if (_tokenMustBeRefreshed()) {
            console.log('token will get refreshed');
            Logon().then(function success(response) {
                var xmlDoc = getXml(response);
                var localToken = xmlDoc.getElementsByTagName('CredentialToken')[0].firstChild.nodeValue;
                token = localToken;
                _getTokenExpiration(token).then(function (tokenExpResult) {
                    var xmlDoc = getXml(tokenExpResult);
                    var expirationDate = xmlDoc.getElementsByTagName('ExpirationDate')[0].firstChild.nodeValue;
                    validUntil = new Date(expirationDate).getTime();
                    resolve(localToken);
                }, function (error) {
                    console.log('error in get token expiration ', error);
                    validUntil = 0;
                    reject(error);
                });
            }, function error(response) {
                console.log('error getting token');
                reject(response);
            });
        } else {
            resolve(token);
        }
    });
};

var _removeToken = function _removeToken() {
    token = false;
    validUntil = false;
};

var generateBodyForMyPrograms = function generateBodyForMyPrograms(token, page) {
    "use strict";

    return '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc" xmlns:pub="http://affilinet.framework.webservices/types/PublisherProgram" xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:GetProgramsRequest>' + '<svc:CredentialToken>' + token + '</svc:CredentialToken>' + '<svc:DisplaySettings><pub:CurrentPage>' + page + '</pub:CurrentPage><pub:PageSize>100</pub:PageSize></svc:DisplaySettings>' + '<svc:GetProgramsQuery>' +
    //'<pub:ProgramIds><arr:int>'+programId +'</arr:int></pub:ProgramIds>'+
    '<pub:PartnershipStatus>' + '<pub:ProgramPartnershipStatusEnum>Active</pub:ProgramPartnershipStatusEnum>' +
    //'<pub:ProgramPartnershipStatusEnum>Paused</pub:ProgramPartnershipStatusEnum>' +
    //'<pub:ProgramPartnershipStatusEnum>Waiting</pub:ProgramPartnershipStatusEnum>' +
    //'<pub:ProgramPartnershipStatusEnum>Cancelled</pub:ProgramPartnershipStatusEnum>' +
    '</pub:PartnershipStatus>' + '</svc:GetProgramsQuery>' + '</svc:GetProgramsRequest>' + '</soapenv:Body>' + '</soapenv:Envelope>';
};

var Logon = function Logon() {
    console.log('in logon');
    return new Promise(function (resolve, reject) {
        var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc" xmlns:typ="http://affilinet.framework.webservices/types">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:LogonRequestMsg>' + '<typ:Username>' + publisherId.trim() + '</typ:Username>' + '<typ:Password>' + webservicePassword.trim() + '</typ:Password>' + '<typ:WebServiceType>Publisher</typ:WebServiceType>' + '</svc:LogonRequestMsg>' + '</soapenv:Body>' + '</soapenv:Envelope>';
        _sendRequest(requestBody, 'https://api.affili.net/V2.0/Logon.svc', 'http://affilinet.framework.webservices/Svc/ServiceContract1/Logon').then(resolve, reject);
    });
};

var _getTokenExpiration = function _getTokenExpiration(token) {
    console.log('in GetTokenExpiration');
    return new Promise(function (resolve, reject) {
        var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc">' + '   <soapenv:Header/>' + '   <soapenv:Body>' + '      <svc:CredentialToken>' + token + '</svc:CredentialToken>' + '   </soapenv:Body>' + '</soapenv:Envelope>';
        _sendRequest(requestBody, 'https://api.affili.net/V2.0/Logon.svc', 'http://affilinet.framework.webservices/Svc/AuthenticationContract/GetIdentifierExpiration').then(resolve, reject);
    });
};
var _fetchAllMyProgramsPages = function _fetchAllMyProgramsPages(totalPages, token) {
    var startWith = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;

    _fetchOneOfMyProgramsPage(startWith, token).then(function (response) {
        var xmlDoc = getXml(response);
        var ProgramCollection = xmlDoc.getElementsByTagName("ProgramCollection")[0];
        var items = ProgramCollection.getElementsByTagName("a:Program");
        for (var i = 0; i < items.length; i++) {
            var newProgram = {
                programId: items[i].getElementsByTagName("a:ProgramId")[0].firstChild.nodeValue,
                programTitle: items[i].getElementsByTagName("a:ProgramTitle")[0].firstChild.nodeValue
            };
            myProgramsCache.push(newProgram);
        }

        if (startWith < totalPages) {
            _fetchAllMyProgramsPages(totalPages, token, startWith + 1);
        } else {
            console.log('INFO: Webservice returned', myProgramsCache.length, ' Program Partnership');
            _storage2.default.set({ myPrograms: myProgramsCache });
            console.debug('added page ' + myProgramsCache.length + ' Programs of myPrograms');
        }
    });
};

var _fetchOneOfMyProgramsPage = function _fetchOneOfMyProgramsPage(page, token) {
    console.log('Send Request for page', page);
    return _sendRequest(generateBodyForMyPrograms(token, page), 'https://api.affili.net/V2.0/PublisherProgram.svc', 'http://affilinet.framework.webservices/Svc/PublisherProgramContract/SearchPrograms');
};

var PublisherWebservice = function () {
    function PublisherWebservice() {
        _classCallCheck(this, PublisherWebservice);

        console.log('created Publisher Webservice');
    }

    _createClass(PublisherWebservice, [{
        key: 'GetLinkedAccounts',
        value: function GetLinkedAccounts() {
            console.debug('in Method GetLinkedAccounts');
            return new Promise(function (resolve, reject) {
                "use strict";

                getToken().then(function success(response) {
                    console.debug('in Method GetLinkedAccounts:success');

                    var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:GetLinkedAccountsRequest>' + '<svc:CredentialToken>' + response + '</svc:CredentialToken>' + '<svc:PublisherId>' + publisherId + '</svc:PublisherId>' + '</svc:GetLinkedAccountsRequest>' + '</soapenv:Body>' + '</soapenv:Envelope>';

                    console.debug('LinkedAccounts Request:');

                    _sendRequest(requestBody, 'http://api.affili.net/V2.0/AccountService.svc', 'http://affilinet.framework.webservices/Svc/AccountServiceContract/GetLinkedAccounts').then(resolve, reject);
                }, function error() {
                    console.debug('in Method GetLinkedAccounts:error');
                    reject();
                });
            });
        }
    }, {
        key: 'GetPublisherSummary',
        value: function GetPublisherSummary() {
            console.debug('in Method GetPublisherSummary');
            return new Promise(function (resolve, reject) {
                "use strict";

                getToken().then(function success(response) {
                    var requestBody = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:svc="http://affilinet.framework.webservices/Svc">' + '<soapenv:Header/>' + '<soapenv:Body>' + '<svc:CredentialToken>' + response + '</svc:CredentialToken>' + '</soapenv:Body>' + '</soapenv:Envelope>';
                    _sendRequest(requestBody, 'http://api.affili.net/V2.0/AccountService.svc', 'http://affilinet.framework.webservices/Svc/AccountServiceContract/GetPublisherSummary').then(resolve, reject);
                }, function error(error) {
                    console.debug('Error in Method GetPublisherSummary', error);
                    reject(error);
                });
            });
        }
    }, {
        key: 'UpdateMyPrograms',
        value: function UpdateMyPrograms() {

            _storage2.default.remove('myPrograms');
            myProgramsCache = [];

            // hole die ersten 100 ergebnisse

            getToken().then(function success(token) {
                var page = 1;
                _sendRequest(generateBodyForMyPrograms(token, page), 'https://api.affili.net/V2.0/PublisherProgram.svc', 'http://affilinet.framework.webservices/Svc/PublisherProgramContract/SearchPrograms').then(function (response) {
                    // checke ob mehr als 100
                    var xmlDoc = getXml(response);
                    var totalResults = xmlDoc.getElementsByTagName("TotalResults")[0].firstChild.nodeValue;
                    var ProgramCollection = xmlDoc.getElementsByTagName("ProgramCollection")[0];
                    var resultsOnThisPage = ProgramCollection.getElementsByTagName("a:Program").length;

                    var totalPages = Math.ceil(totalResults / 100);
                    console.log('INFO: Webservice Reports ', totalResults, ' Partnerships on ', totalPages, ' Pages.. fetching data from webserivice');

                    _fetchAllMyProgramsPages(totalPages, token, 1);
                }, console.debug);
            }, function error() {
                console.debug('in Method GetAllPrograms:error');
            });

            // wenn mehr als 100 iteriere bis maximale anzahl erreicht ist

        }
    }, {
        key: 'Reset',
        value: function Reset() {
            "use strict";

            _removeToken();
        }
    }, {
        key: 'UpdateCredentials',
        value: function UpdateCredentials(pub, pass) {
            publisherId = pub;
            webservicePassword = pass;
        }
    }]);

    return PublisherWebservice;
}();

var publisherWebservice = new PublisherWebservice();
module.exports = publisherWebservice;

},{"../utils/storage":5}],4:[function(require,module,exports){
'use strict';

var apis = ['alarms', 'bookmarks', 'browserAction', 'commands', 'contextMenus', 'cookies', 'downloads', 'events', 'extension', 'extensionTypes', 'history', 'i18n', 'idle', 'notifications', 'pageAction', 'runtime', 'storage', 'tabs', 'webNavigation', 'webRequest', 'windows'];

function Extension() {
  var _this = this;

  apis.forEach(function (api) {

    _this[api] = null;

    try {
      if (chrome[api]) {
        _this[api] = chrome[api];
      }
    } catch (e) {}

    try {
      if (window[api]) {
        _this[api] = window[api];
      }
    } catch (e) {}

    try {
      if (browser[api]) {
        _this[api] = browser[api];
      }
    } catch (e) {}
    try {
      _this.api = browser.extension[api];
    } catch (e) {}
  });

  try {
    if (browser && browser.runtime) {
      this.runtime = browser.runtime;
    }
  } catch (e) {}

  try {
    if (browser && browser.browserAction) {
      this.browserAction = browser.browserAction;
    }
  } catch (e) {}
}

/**
 * @typedef {Object} FooEngine
 * @property {function(string, boolean)} start Starts the [Foo/Bar] Engine
 */

/**
 * The Browser Extensions
 * @typedef {Object} Extension
 * @proptery {function} alarms
 * @proptery {function} bookmarks
 * @proptery {function} browserAction
 * @proptery {function} commands
 * @proptery {function} contextMenus
 * @proptery {function} cookies
 * @proptery {function} downloads
 * @proptery {function} events
 * @proptery {function} extension
 * @proptery {function} extensionTypes
 * @proptery {function} history
 * @proptery {function} i18n
 * @proptery {function} idle
 * @proptery {function} notifications
 * @proptery {function} pageAction
 * @proptery {function} runtime
 * @proptery {function} storage
 * @proptery {function} tabs
 * @proptery {function} webNavigation
 * @proptery {function} webRequest
 * @proptery {function} windows
 */

var ext = new Extension();

module.exports = ext;

},{}],5:[function(require,module,exports){
"use strict";

var _ext = require("./ext");

var _ext2 = _interopRequireDefault(_ext);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 *  * @typedef chrome.storage.local storage
 */
var storage = _ext2.default.storage.local;
module.exports = storage;

},{"./ext":4}]},{},[1])

//# sourceMappingURL=background.js.map
